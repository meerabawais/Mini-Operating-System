#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {
    srand(time(0));
    int number = rand() % 100 + 1; // Random number between 1 and 100
    int guess;
    int attempts = 0;

    cout << "====== Guess the Number Game ======\n";
    cout << "I'm thinking of a number between 1 and 100.\n";
    cout << "Enter -1 at any time to quit.\n";

    do {
        cout << "Enter your guess: ";
        cin >> guess;

        if (guess == -1) {
            cout << "You chose to quit the game. The number was: " << number << endl;
            break;
        }

        attempts++;

        if (guess < number) {
            cout << "Too low!\n";
        } else if (guess > number) {
            cout << "Too high!\n";
        } else {
            cout << "Congratulations! You guessed it in " << attempts << " attempts.\n";
        }

    } while (guess != number);

    return 0;
}

