#include <iostream>
#include <cstdlib>

using namespace std;

int main() {
    string filename;
    cout << "Enter the name of the video file (without .mp4): ";
    cin >> filename;
    string command = "xdg-open " + filename + ".mp4";
    system(command.c_str());
    return 0;
}

