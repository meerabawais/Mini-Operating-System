#include <iostream>
#include <unistd.h>
using namespace std;

// Function to print the Tic-Tac-Toe board
void printboard(int board[3][3]) {
    cout << "\nCurrent Board:\n";
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (board[i][j] == 0)
                cout << "_ ";
            else if (board[i][j] == 1)
                cout << "X ";
            else
                cout << "O ";
        }
        cout << endl;
    }
    cout << endl;
}

// Function to check if there's a winner
bool checkwinner(int board[3][3], int& who) {
    // Rows and columns
    for (int i = 0; i < 3; i++) {
        if (board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] != 0) {
            who = board[i][0];
            return true;
        }
        if (board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] != 0) {
            who = board[0][i];
            return true;
        }
    }

    // Diagonals
    if (board[0][0] == board[1][1] && board[0][0] == board[2][2] && board[0][0] != 0) {
        who = board[0][0];
        return true;
    }
    if (board[0][2] == board[1][1] && board[0][2] == board[2][0] && board[0][2] != 0) {
        who = board[0][2];
        return true;
    }

    return false;
}

int main() {
    char choice;
    cout << "tictactoe started (PID: " << getpid() << ")\n";
    while (true)
    {
        cout << "Do you want to play this game? (q to quit,m to minimize and any other key to continue): ";
        cin >> choice;

        if (choice == 'q' || choice == 'Q') {
            break;
        }

        if (choice == 'm' || choice == 'M') {
            cout << "minimizing tictactoe PID ( " << getpid() << "), you can resume later.\n";
            continue;
        }
        int board[3][3] = { 0 };  // Empty board
        int player = 1;         // Player 1 starts
        int row, col;
        int who;
        bool winner = false;

        cout << "Welcome to Tic-Tac-Toe!\n";
        printboard(board);

        for (int turn = 0; turn < 9 && !winner; turn++) {
            cout << "Player " << player << "'s turn.\n";

            cout << "Enter row (0-2) and column (0-2): ";
            cin >> row >> col;

            while (row < 0 || row > 2 || col < 0 || col > 2 || board[row][col] != 0) {
                cout << "Invalid or occupied cell. Try again: ";
                cin >> row >> col;
            }

            board[row][col] = player;
            printboard(board);

            winner = checkwinner(board, who);

            if (winner) {
                cout << "The winner is Player " << who << "!\n";
                break;
            }

            // Ask if user wants to quit
            int choice;
            cout << "Press 1 to continue, 0 to quit: ";
            cin >> choice;
            if (choice == 0) {
                cout << "Game ended by user.\n";
                break;
            }

            // Switch player
            player = (player == 1) ? 2 : 1;
        }

        if (!winner) {
            cout << "Game ended in a draw.\n";
        }
    }

    return 0;
}
